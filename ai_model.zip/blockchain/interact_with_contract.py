from web3 import Web3
import json
import sys
import os
import time
import wikipedia

sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))
from ai_model.factspeak_ai import get_fact_based_answer
from validator.truth_checker import check_truth

# Connect to local Ganache
w3 = Web3(Web3.HTTPProvider("http://127.0.0.1:7545"))

# Load ABI
abi_path = os.path.join(os.path.dirname(__file__), "EthicalValidationABI.json")
if not os.path.exists(abi_path) or os.path.getsize(abi_path) == 0:
    print("❌ ABI file missing or empty!")
    sys.exit(1)

with open(abi_path, "r", encoding="utf-8") as f:
    abi = json.load(f)
    print("✅ ABI loaded successfully.")

# Set contract
contract_address = w3.to_checksum_address("0x27bc519DBF09c441717a4C3E101c54B2236b557F")  # Replace if needed
contract = w3.eth.contract(address=contract_address, abi=abi)
account = w3.eth.accounts[0]

# Get question from user
question = input("Enter your question for FactSpeak AI:\n> ")

# Automatically get context from Wikipedia
try:
    context = wikipedia.summary(question, sentences=2)
except Exception as e:
    print(f"⚠️ Could not fetch Wikipedia context: {e}")
    context = ""

# Run AI model
ai_answer = get_fact_based_answer(question, context)
print(f"\n🤖 AI Answer: {ai_answer}")

# Validate answer
is_truthful, message = check_truth(question, ai_answer)
print(f"✅ Validation: {message}")

# Log to blockchain
try:
    tx = contract.functions.logValidation(
        question,
        ai_answer,
        is_truthful
    ).transact({'from': account})
    w3.eth.wait_for_transaction_receipt(tx)
    print("✅ Logged to blockchain. Tx hash:", w3.to_hex(tx))
except Exception as e:
    print("❌ Error during blockchain transaction:", e)
